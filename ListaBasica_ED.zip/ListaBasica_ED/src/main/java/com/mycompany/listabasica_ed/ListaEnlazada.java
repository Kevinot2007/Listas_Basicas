package com.mycompany.listabasica_ed;
import java.util.Scanner;

/**
 * LISTA ENLAZADA SIMPLE por  Jaider Enrique Reyes Herazo
 *
 * Mantiene una referencia al primer Nodo (cabeza).
 * Cada Nodo apunta al siguiente a través de su campo "enlace".
 *
 *   cabeza → [10] → [20] → [30] → null
 */
public class ListaEnlazada {

    // Referencia al primer nodo de la lista (ENLACE inicial)
    private Nodo cabeza;

    // ── Constructor ───────────────────────────────────────────────────────
    public ListaEnlazada() {
        cabeza = null;  // lista vacía al inicio
    }

    // ── Insertar al final ─────────────────────────────────────────────────
    public void insertar(int dato) {
        Nodo nuevo = new Nodo(dato);

        if (cabeza == null) {
            cabeza = nuevo;
        } else {
            Nodo actual = cabeza;
            while (actual.enlace != null) {     // mientras haya ENLACE
                actual = actual.enlace;          // avanzar por el ENLACE
            }
            actual.enlace = nuevo;              // conectar ENLACE al nuevo nodo
        }
    }

    // ── Insertar UN dato leído por teclado ────────────────────────────────
    public void insertarPorTeclado(Scanner sc) {
        int dato = leerEntero(sc, "Ingresa el dato a insertar: ");
        insertar(dato);
        System.out.println("Dato " + dato + " insertado.");
        mostrar();
    }

    // ── Insertar VARIOS datos leídos por teclado ──────────────────────────
    public void insertarVariosPorTeclado(Scanner sc) {
        int cantidad = leerEntero(sc, "¿Cuántos datos vas a insertar? ");
        for (int i = 1; i <= cantidad; i++) {
            int dato = leerEntero(sc, "Dato " + i + " de " + cantidad + ": ");
            insertar(dato);
        }
        mostrar();
    }

    // ── Eliminar un dato pedido por teclado ───────────────────────────────
    public void eliminarPorTeclado(Scanner sc) {
        int dato = leerEntero(sc, "Dato a eliminar: ");
        if (buscar(dato)) {
            eliminar(dato);
            System.out.println("Dato " + dato + " eliminado.");
        } else {
            System.out.println("El dato " + dato + " no existe.");
        }
        mostrar();
    }

    // ── Buscar un dato pedido por teclado ─────────────────────────────────
    public void buscarPorTeclado(Scanner sc) {
        int dato = leerEntero(sc, "Dato a buscar: ");
        System.out.println(buscar(dato)
                ? "✔ El dato " + dato + " SÍ está en la lista."
                : "✘ El dato " + dato + " NO está en la lista.");
    }

    // ── Lee un entero validando que no se escriban letras ─────────────────
    public static int leerEntero(Scanner sc, String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String texto = sc.nextLine().trim();
            try {
                return Integer.parseInt(texto);
            } catch (NumberFormatException ex) {
                System.out.println("⚠ Entrada inválida. Escribe un número entero.");
            }
        }
    }

    // ── Eliminar por valor ────────────────────────────────────────────────
    public void eliminar(int dato) {
        if (cabeza == null) return;

        if (cabeza.dato == dato) {
            cabeza = cabeza.enlace;
            return;
        }

        Nodo anterior = cabeza;
        while (anterior.enlace != null && anterior.enlace.dato != dato) {
            anterior = anterior.enlace;
        }

        if (anterior.enlace != null) {
            anterior.enlace = anterior.enlace.enlace;
        }
    }

    // ── Buscar ────────────────────────────────────────────────────────────
    public boolean buscar(int dato) {
        Nodo actual = cabeza;
        while (actual != null) {
            if (actual.dato == dato) return true;
            actual = actual.enlace;
        }
        return false;
    }

    // ── Mostrar la lista ──────────────────────────────────────────────────
    public void mostrar() {
        if (cabeza == null) {
            System.out.println("Lista vacía");
            return;
        }
        Nodo actual = cabeza;
        System.out.print("cabeza → ");
        while (actual != null) {
            System.out.print(actual + " → ");
            actual = actual.enlace;
        }
        System.out.println("null");
    }

    // ── Tamaño ────────────────────────────────────────────────────────────
    public int tamanio() {
        int contador = 0;
        Nodo actual = cabeza;
        while (actual != null) {
            contador++;
            actual = actual.enlace;
        }
        return contador;
    }
}